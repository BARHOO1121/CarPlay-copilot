package com.shilapi.xcertplay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs

class CarXFloatService : Service() {
    private var wm: WindowManager? = null
    private var bubble: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = (64 * resources.displayMetrics.density).toInt()
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.rgb(24, 27, 32))
            setStroke((2 * resources.displayMetrics.density).toInt(), Color.rgb(210, 172, 92))
        }
        val v = TextView(this).apply {
            text = "Car X"
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            background = bg
            elevation = 12f * resources.displayMetrics.density
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 220 }
        var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
        v.setOnTouchListener { _, e ->
            when(e.action) {
                MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=lp.x; oy=lp.y; moved=false; true }
                MotionEvent.ACTION_MOVE -> { if(abs(e.rawX-sx)>8 || abs(e.rawY-sy)>8) moved=true; lp.x=ox+(e.rawX-sx).toInt(); lp.y=oy+(e.rawY-sy).toInt(); wm?.updateViewLayout(v,lp); true }
                MotionEvent.ACTION_UP -> { if(!moved) openCarPlay(); true }
                else -> false
            }
        }
        bubble=v; params=lp; wm?.addView(v,lp)
    }

    private fun openCarPlay() {
        startActivity(Intent(this, CarPlayHostActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        })
    }
    override fun onDestroy() { bubble?.let { runCatching { wm?.removeView(it) } }; bubble=null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
