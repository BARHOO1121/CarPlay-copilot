package com.shilapi.xcertplay.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = DriveAccent,
    onPrimary = DriveBackground,
    secondary = DriveMuted,
    onSecondary = DriveBackground,
    tertiary = DriveSuccess,
    background = DriveBackground,
    onBackground = DriveText,
    surface = DriveSurface,
    onSurface = DriveText,
    surfaceVariant = DriveSurfaceRaised,
    onSurfaceVariant = DriveMuted,
    outline = DriveBorder,
    error = DriveError,
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF355F95),
    onPrimary = Color.White,
    secondary = Color(0xFF43556F),
    tertiary = Color(0xFF28745C),
    background = Color(0xFFF5F7FA),
    onBackground = Color(0xFF17202D),
    surface = Color.White,
    onSurface = Color(0xFF17202D),
    surfaceVariant = Color(0xFFE8EDF4),
    onSurfaceVariant = Color(0xFF43556F),
    outline = Color(0xFFBBC6D5),
    error = Color(0xFFB3261E),
)

@Composable
fun XcertplayTheme(
    darkTheme: Boolean = true,
    // Dynamic color is available on Android 12+
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}