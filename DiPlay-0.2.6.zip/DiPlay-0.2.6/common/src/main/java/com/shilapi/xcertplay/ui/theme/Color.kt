package com.shilapi.xcertplay.ui.theme

import androidx.compose.ui.graphics.Color

val DriveBackground = Color(0xFF0B1018)
val DriveSurface = Color(0xFF141D2B)
val DriveSurfaceRaised = Color(0xFF1B2637)
val DriveBorder = Color(0xFF29384D)
val DriveAccent = Color(0xFFA6C8FF)
val DriveText = Color(0xFFF2F5FA)
val DriveMuted = Color(0xFFA8B6CA)
val DriveSuccess = Color(0xFF49D3A5)
val DriveWarning = Color(0xFFFFC480)
val DriveError = Color(0xFFFF6B6B)